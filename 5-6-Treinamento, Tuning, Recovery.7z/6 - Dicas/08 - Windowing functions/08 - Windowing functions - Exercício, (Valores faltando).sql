/*
  SQL25 - SQL Server Performance with nowait
  http://www.srnimbus.com.br
*/



----------------------------------------
----------- Valores faltando -----------
----------------------------------------
/*
  Escreva uma consulta que retorne todos os dias sem vendas dentro
  de todo o per�odo de vendas existente.
  Sendo data inicial primeira venda, e data final a �ltima venda.
  Em outras palavras, os valores faltantes.
*/


-- Resultado desejado
/*
  DataSemVenda
  ------------
  1996-12-07
  1996-12-08
  1996-12-14
  1996-12-15
  1996-12-21
  1996-12-22
  1996-12-28
  1996-12-29
*/