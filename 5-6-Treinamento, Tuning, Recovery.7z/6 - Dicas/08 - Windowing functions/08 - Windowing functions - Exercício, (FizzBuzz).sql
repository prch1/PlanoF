/*
  SQL25 - SQL Server Performance with nowait
  http://www.srnimbus.com.br
*/



---------------------------------------
---------- FizzBuzz Problem -----------
---------------------------------------

/*
  Escreva um c�digo onde voc� ir� retornar n�meros de 1 a 100, 
  quando o n�mero for m�ltiplo de 3 voc� ir� escrever �Fizz�, 
  quando o n�mero for m�ltiplo de 5 voc� ir� escrever �Buzz� e 
  quando o n�mero for m�ltiplo de 3 e 5 escreva �FizzBuzz�.
*/
